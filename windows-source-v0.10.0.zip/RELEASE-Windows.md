## 繁體中文

Windows 10 / 11 x64 版。下載 **3DM-to-DXF-Windows-x64-v0.10.0.zip**，解壓縮後把 `.3dm` 拖到 **3DM to DXF.exe**。支援多檔、不顯示主視窗、不啟動 Rhino；輸出放在原資料夾，同名自動加序號。

內含中英文使用說明。`windows-smoke-test.json` 是 Windows runner 執行打包 EXE 的驗證結果；Explorer 拖曳與通知顯示尚需實際桌面測試。程式未具商業程式碼簽章。一般 Brep 實體及其他不支援物件會回報失敗。

macOS 使用者請繼續下載 [v0.9 Mac 版](https://github.com/ZionW/3dm-to-dxf-macos/releases/tag/v0.9)。

## English

Windows 10 / 11 x64 build. Download **3DM-to-DXF-Windows-x64-v0.10.0.zip**, extract it, and drop `.3dm` files onto **3DM to DXF.exe**. Supports multiple files, no main window, no Rhino launch, output beside the source, and automatic suffixes for existing names.

Bilingual instructions are included. `windows-smoke-test.json` records packaged-EXE validation on a Windows runner. Explorer drag gestures and visible notifications still need interactive desktop testing. This build has no commercial code-signing certificate. General Brep solids and other unsupported objects fail with a report.

macOS users should download the [v0.9 Mac build](https://github.com/ZionW/3dm-to-dxf-macos/releases/tag/v0.9).
