// Synthetic test drawing. Contains no customer geometry.
#include "opennurbs.h"
#ifdef _WIN32
int wmain(int argc, wchar_t** argv) {
#else
int main(int argc, char** argv) {
#endif
  if (argc != 2) return 2;
  ON::Begin();
  ONX_Model model;
  model.m_settings.m_ModelUnitsAndTolerances.m_unit_system = ON::LengthUnitSystem::Millimeters;
  ON_Layer layer;
  layer.SetName(L"Fixture");
  layer.SetColor(ON_Color(30, 100, 200));
  const auto lr = model.AddModelComponent(layer);
  ON_3dmObjectAttributes attr;
  attr.m_layer_index = lr.ModelComponent()->Index();
  ON_HatchPattern pattern = ON_HatchPattern::Solid;
  const auto pr = model.AddModelComponent(pattern);
  ON_Circle outer(ON_Plane::World_xy, 8.0), inner(ON_Plane::World_xy, 3.0);
  ON_ArcCurve a(outer), b(inner);
  ON_SimpleArray<const ON_Curve*> loops;
  loops.Append(&a); loops.Append(&b);
  ON_Hatch hatch;
  if (!hatch.Create(ON_Plane::World_xy, loops, pr.ModelComponent()->Index(), 0, 1)) return 3;
  model.AddModelGeometryComponent(&hatch, &attr);
  ON_DimStyle style = ON_DimStyle::Default;
  style.SetName(L"FixtureStyle");
  const auto sr = model.AddModelComponent(style);
  const auto ds = ON_DimStyle::Cast(sr.ModelComponent());
  ON_Text text;
  if (!text.Create(L"Synthetic DXF test", ds, ON_Plane::World_xy)) return 4;
  text.SetDimensionStyleId(ds->Id());
  model.AddModelGeometryComponent(&text, &attr);
  ON_DimLinear dim;
  if (!dim.Create(ON::AnnotationType::Rotated, ds->Id(), ON_Plane::World_xy,
      ON_3dVector::XAxis, ON_3dPoint(0,0,0), ON_3dPoint(20,0,0), ON_3dPoint(0,12,0), 0)) return 5;
  model.AddModelGeometryComponent(&dim, &attr);
  return model.Write(argv[1], 80, nullptr) ? 0 : 6;
}
