#include "opennurbs.h"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <filesystem>
#ifdef _WIN32
int wmain(int argc,wchar_t**argv){
#else
int main(int argc,char**argv){
#endif
 if(argc!=4)return 2; ON::Begin(); ONX_Model model, loops;
 if(!model.Read(argv[1]))return 3;
 std::ofstream out{std::filesystem::path(argv[3])}; out<<std::setprecision(17)<<"{\"hatches\":{";
 ONX_ModelComponentIterator it(model,ON_ModelComponent::Type::ModelGeometry); bool first=true;
 for(auto c=it.FirstComponent();c;c=it.NextComponent()){
  auto mg=ON_ModelGeometryComponent::Cast(c); if(!mg)continue;
  auto h=ON_Hatch::Cast(mg->Geometry(nullptr)); if(!h)continue;
  const auto a=mg->Attributes(nullptr); ON_String id; ON_UuidToString(a->m_uuid,id);
  if(!first)out<<",";first=false;out<<"\""<<id.Array()<<"\":{\"pattern\":"<<h->PatternIndex()<<",\"loops\":[";
  for(int j=0;j<h->LoopCount();j++){
   if(j)out<<","; const auto l=h->Loop(j); ON_3dmObjectAttributes at;
   at.SetUserString(L"source",ON_wString(id)); at.SetUserString(L"loop",ON_wString(std::to_string(j).c_str()));
   loops.AddModelGeometryComponent(l->Curve(),&at); out<<(l->Type()==ON_HatchLoop::ltOuter?1:0);
  } out<<"]}";
 }
 out<<"},\"patterns\":{";first=true;
 ONX_ModelComponentIterator pi(model,ON_ModelComponent::Type::HatchPattern);
 for(auto c=pi.FirstComponent();c;c=pi.NextComponent()){
  auto p=ON_HatchPattern::Cast(c);if(!p)continue;
  if(!first)out<<",";first=false;out<<"\""<<p->Index()<<"\":[";
  for(int j=0;j<p->HatchLineCount();j++){
   auto l=p->HatchLine(j);if(j)out<<",";
   out<<"["<<l->AngleDegrees()<<",["<<l->Base().x<<","<<l->Base().y<<"],["<<l->Offset().x<<","<<l->Offset().y<<"],[";
   for(int k=0;k<l->DashCount();k++){if(k)out<<",";out<<l->Dash(k);}out<<"]]";
  }out<<"]";
 }
 out<<"},\"texts\":{";first=true;
 ONX_ModelComponentIterator ti(model,ON_ModelComponent::Type::ModelGeometry);
 for(auto c=ti.FirstComponent();c;c=ti.NextComponent()){
  auto mg=ON_ModelGeometryComponent::Cast(c);if(!mg)continue;
  auto t=ON_Text::Cast(mg->Geometry(nullptr));if(!t)continue;
  auto ref=model.ComponentFromId(ON_ModelComponent::Type::DimStyle,t->DimensionStyleId());
  auto ds=ON_DimStyle::Cast(ref.ModelComponent());if(!ds)ds=&ON_DimStyle::Default;
  ON_String id; ON_UuidToString(mg->Attributes(nullptr)->m_uuid,id);
  ON::TextHorizontalAlignment ha;ON::TextVerticalAlignment va;t->GetAlignment(ha,va);
  if(!first)out<<",";first=false;
  out<<"\""<<id.Array()<<"\":{\"height\":"<<t->TextHeight(ds)<<",\"scale\":"<<t->DimScale(ds)<<",\"horizontal\":"<<int(ha)<<",\"vertical\":"<<int(va)<<"}";
 }
 out<<"},\"details\":{";first=true;
 ONX_ModelComponentIterator di(model,ON_ModelComponent::Type::ModelGeometry);
 for(auto c=di.FirstComponent();c;c=di.NextComponent()){
  auto mg=ON_ModelGeometryComponent::Cast(c);if(!mg)continue;
  auto d=ON_DetailView::Cast(mg->Geometry(nullptr));if(!d)continue;
  ON_String id;ON_UuidToString(mg->Attributes(nullptr)->m_uuid,id);
  auto b=d->m_boundary.BoundingBox(); auto target=d->m_view.m_vp.TargetPoint();
  auto dir=d->m_view.m_vp.CameraDirection();double l,r,bottom,top;d->m_view.m_vp.GetFrustum(&l,&r,&bottom,&top);
  if(!first)out<<",";first=false;
  out<<"\""<<id.Array()<<"\":{\"bounds\":["<<b.m_min.x<<","<<b.m_min.y<<","<<b.m_max.x<<","<<b.m_max.y<<"],\"target\":["<<target.x<<","<<target.y<<","<<target.z<<"],\"direction\":["<<-dir.x<<","<<-dir.y<<","<<-dir.z<<"],\"height\":"<<top-bottom<<"}";
 }
 out<<"}}";if(!loops.Write(argv[2],60,nullptr))return 4;return out.good()?0:5;
}
