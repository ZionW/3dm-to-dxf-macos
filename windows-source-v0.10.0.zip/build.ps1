param([string]$Version = '0.10.0')
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
function Check-Exit { if ($LASTEXITCODE -ne 0) { throw "Command failed with exit code $LASTEXITCODE" } }
if (-not (Test-Path vendor/opennurbs/CMakeLists.txt)) {
  git clone --no-checkout https://github.com/mcneel/opennurbs.git vendor/opennurbs
  Check-Exit
}
git -C vendor/opennurbs checkout eb92af3ba1806b0a34a99aba0d3bda83e3d46083
Check-Exit
python -m pip install --only-binary=:all: -r requirements.txt
Check-Exit
$OpenNurbs = (Resolve-Path vendor/opennurbs).Path
cmake -S native -B build-native -A x64 "-DOPENNURBS_SOURCE=$OpenNurbs"
Check-Exit
cmake --build build-native --config Release --target extract make_fixture --parallel 4
Check-Exit
$env:THREEDM_EXTRACTOR = (Resolve-Path build-native/Release/extract.exe).Path
python tests/smoke.py --fixture build-native/Release/make_fixture.exe --report core-smoke-test.json
Check-Exit
Remove-Item Env:THREEDM_EXTRACTOR
python -m PyInstaller --noconfirm --clean --onefile --windowed --name '3DM to DXF' --icon assets/icon.ico --paths src --add-binary 'build-native/Release/extract.exe;.' --collect-all rhino3dm --exclude-module matplotlib src/windows_app.py
Check-Exit
python tests/smoke.py --exe 'dist/3DM to DXF.exe' --fixture build-native/Release/make_fixture.exe --report windows-smoke-test.json
Check-Exit
python package_release.py --version $Version
Check-Exit
