import argparse
import hashlib
from importlib import metadata
from pathlib import Path
import shutil
import sys
import zipfile

def main(version):
    root=Path(__file__).resolve().parent
    stage=root/'release'/'3DM to DXF Windows'
    stage.mkdir(parents=True,exist_ok=True)
    shutil.copy2(root/'dist/3DM to DXF.exe',stage/'3DM to DXF.exe')
    for filename in ['README.Windows.zh-TW.md','README.Windows.en.md','windows-smoke-test.json']:
        shutil.copy2(root/filename,stage/filename)
    licenses=stage/'THIRD-PARTY-LICENSES';licenses.mkdir(exist_ok=True)
    shutil.copy2(root/'vendor/opennurbs/LICENSE',licenses/'openNURBS-and-zlib.txt')
    for name in ['rhino3dm','ezdxf','Pillow','numpy','fonttools','pyparsing','typing_extensions','pyinstaller']:
        dist=metadata.distribution(name)
        target=licenses/name;target.mkdir(exist_ok=True)
        for item in dist.files or []:
            if ('license' in item.name.lower() or 'copying' in item.name.lower()) and '.dist-info' in str(item):
                path=Path(dist.locate_file(item))
                if path.is_file():shutil.copy2(path,target/item.name)
    for path in [Path(sys.base_prefix)/'LICENSE.txt',Path(sys.base_prefix)/'LICENSE']:
        if path.is_file():shutil.copy2(path,licenses/'Python.txt');break
    zip_path=root/'release'/f'3DM-to-DXF-Windows-x64-v{version}.zip'
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in sorted(stage.rglob('*')):
            if path.is_file():z.write(path,path.relative_to(stage.parent))
    digest=hashlib.sha256(zip_path.read_bytes()).hexdigest()
    (zip_path.parent/'SHA256SUMS-Windows.txt').write_text(f'{digest}  {zip_path.name}\n',encoding='utf-8')
    shutil.copy2(root/'windows-smoke-test.json',zip_path.parent/'windows-smoke-test.json')
    print(f'{zip_path.name}: {zip_path.stat().st_size} bytes, SHA256 {digest}')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--version',default='0.10.0');main(p.parse_args().version)
