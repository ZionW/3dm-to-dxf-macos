"""Exact hatch extraction, drawing attributes, and verified DXF writing."""
import base64
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
from collections import Counter, defaultdict
import ezdxf
from ezdxf.math import Matrix44, Vec3
import rhino3dm as r

SOURCE_APP = 'THREEDM_SOURCE'


def resources():
    if getattr(sys, 'frozen', False):
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parents[1] / 'resources'


def extract(source, temp):
    helper = Path(os.environ.get('THREEDM_EXTRACTOR', str(resources() / ('extract.exe' if os.name == 'nt' else 'extract'))))
    options = {'creationflags': subprocess.CREATE_NO_WINDOW} if os.name == 'nt' else {}
    subprocess.run([str(helper), str(source), str(temp/'loops.3dm'), str(temp/'metadata.json')], check=True, capture_output=True, timeout=120, **options)
    metadata = json.loads((temp/'metadata.json').read_text(encoding='utf-8'))
    loops = defaultdict(dict)
    for obj in r.File3dm.Read(str(temp/'loops.3dm')).Objects:
        loops[obj.Attributes.GetUserString('source')][int(obj.Attributes.GetUserString('loop'))] = obj.Geometry
    return metadata, loops


def spline_data(curve):
    points = list(curve.Points)
    return ([(p.X/p.W, p.Y/p.W) for p in points], [p.W for p in points],
            [curve.Knots[0]] + list(curve.Knots) + [curve.Knots[len(curve.Knots)-1]])


def hatch_edge(path, curve):
    poly = curve.TryGetPolyline()
    if poly is not None:
        for a,b in zip(poly, list(poly)[1:]):
            path.add_line((a.X,a.Y),(b.X,b.Y))
    elif isinstance(curve, r.PolyCurve):
        for i in range(curve.SegmentCount):
            hatch_edge(path, curve.SegmentCurve(i))
    else:
        # NURBS boundary edges retain exact rational geometry and curve direction.
        nurbs = curve if isinstance(curve,r.NurbsCurve) else curve.ToNurbsCurve()
        if nurbs is None:
            raise ValueError('填色邊界無法轉成精確曲線')
        points,weights,knots=spline_data(nurbs)
        path.add_spline(control_points=points,weights=weights,knot_values=knots,
                        degree=nurbs.Degree,periodic=int(nurbs.IsPeriodic))


def add_hatch(space, geometry, uid, metadata, loops, attrs):
    h=space.add_hatch(dxfattribs=attrs)
    pattern=metadata['patterns'].get(str(geometry.PatternIndex))
    if pattern is None:
        raise ValueError('缺少填色圖樣定義')
    if pattern:
        definition=[]
        for angle,base,offset,dashes in pattern:
            a=math.radians(angle)
            offset=(offset[0]*math.cos(a)-offset[1]*math.sin(a),offset[0]*math.sin(a)+offset[1]*math.cos(a))
            definition.append([angle,base,offset,dashes])
        h.set_pattern_fill('RHINO_'+str(geometry.PatternIndex),color=256,
            angle=math.degrees(geometry.PatternRotation),scale=geometry.PatternScale,definition=definition)
    else:
        h.set_solid_fill(color=256)
    for i,outer in enumerate(metadata['hatches'][uid]['loops']):
        hatch_edge(h.paths.add_edge_path(flags=1 if outer else 0), loops[uid][i])
    p=geometry.Plane
    mat=Matrix44.ucs(Vec3(p.XAxis.X,p.XAxis.Y,p.XAxis.Z),Vec3(p.YAxis.X,p.YAxis.Y,p.YAxis.Z),Vec3(p.ZAxis.X,p.ZAxis.Y,p.ZAxis.Z),Vec3(p.Origin.X,p.Origin.Y,p.Origin.Z))
    h.transform(mat)
    return h


def add_text(space, geometry, uid, metadata, attrs):
    data=metadata['texts'][uid]
    # Rhino text uses annotation scale even when stored text height is small.
    height=data['height']*data['scale']
    p=geometry.Plane
    horizontal=min(data['horizontal'],2)
    vertical={0:0,1:1,2:2,3:1,4:1,5:2,6:2}[data['vertical']]
    text=geometry.PlainText.replace('\\','\\\\').replace('{','\\{').replace('}','\\}').replace('\r\n','\n').replace('\n',r'\P')
    font=re.search(r'\\f0 ([^;{}]+);',geometry.RichText)
    if font:
        text=r'{\f'+font.group(1)+r'|b0|i0;'+text+'}'
    return space.add_mtext(text,dxfattribs={**attrs,'char_height':height,
        'insert':(p.Origin.X,p.Origin.Y,p.Origin.Z),'text_direction':(p.XAxis.X,p.XAxis.Y,p.XAxis.Z),
        'extrusion':(p.ZAxis.X,p.ZAxis.Y,p.ZAxis.Z),'attachment_point':vertical*3+horizontal+1})


def add_picture(drawing, space, model, item, source, attrs):
    from PIL import Image
    geom=item.Geometry
    if len(geom.Faces)!=1 or len(geom.Surfaces)!=1:
        raise ValueError('尚未支援一般曲面實體；已停止輸出，避免物件遺失')
    try:
        texture=model.Materials[item.Attributes.MaterialIndex].GetBitmapTexture()
        name=Path(texture.FileName).name if texture else ''
    except (IndexError,AttributeError):
        name=''
    if not name:
        raise ValueError('尚未支援一般曲面實體；已停止輸出，避免物件遺失')
    folder=source.with_name(source.stem+'_embedded_files')
    image=folder/name
    if not image.is_file():
        for embedded in model.EmbeddedFilePaths():
            if Path(embedded).name==name:
                folder.mkdir(exist_ok=True)
                data=base64.b64decode(model.GetEmbeddedFileAsBase64(embedded))
                with image.open('xb') as f:f.write(data)
                break
    if not image.is_file():
        original=Path(texture.FileName)
        if original.is_file():
            folder.mkdir(exist_ok=True)
            import shutil
            shutil.copy2(original,image)
        else:
            raise ValueError('找不到參考圖片：'+name)
    with Image.open(image) as im: size=im.size
    surface=geom.Surfaces[0];u,v=surface.Domain(0),surface.Domain(1)
    def vec(pt):return Vec3(pt.X,pt.Y,pt.Z)
    origin=vec(surface.PointAt(u.T0,v.T0));ux=vec(surface.PointAt(u.T1,v.T0))-origin;vy=vec(surface.PointAt(u.T0,v.T1))-origin
    if not surface.IsPlanar() or abs(ux.normalize().dot(vy.normalize()))>1e-8:
        raise ValueError('圖片曲面不是正交平面，無法完整保留')
    definition=drawing.add_image_def(str(image.relative_to(source.parent)),size_in_pixel=size)
    entity=space.add_image(definition,origin,(ux.magnitude,vy.magnitude),dxfattribs=attrs)
    entity.dxf.u_pixel=ux/size[0];entity.dxf.v_pixel=vy/size[1]
    return entity


def inventory(drawing):
    result=defaultdict(Counter)
    spaces=list(drawing.layouts)+list(drawing.blocks)
    for space in spaces:
        for entity in space:
            if entity.has_xdata(SOURCE_APP):
                uid=entity.get_xdata(SOURCE_APP)[0].value
                extra=''
                if entity.dxftype()=='HATCH':extra=':'+str(len(entity.paths))
                result[uid][entity.dxftype()+extra]+=1
    return dict(result)


def write_verified(drawing, temporary):
    dxf = temporary / 'model.dxf'
    drawing.saveas(dxf, fmt='asc')
    restored = ezdxf.readfile(dxf)
    if inventory(drawing) != inventory(restored):
        raise RuntimeError('DXF 回讀核對失敗：物件或填色數量不一致，已停止發布')
    audit = restored.audit()
    if audit.has_errors or audit.has_fixes:
        raise RuntimeError('DXF 回讀需要修復，已停止發布')
    return dxf, restored


def add_instance(space, geometry, names, attrs):
    """Represent an orthogonal Rhino instance transform as a DXF INSERT."""
    identifier = str(geometry.ParentIdefId)
    if identifier not in names:
        raise ValueError('找不到區塊定義：' + identifier)
    t = geometry.Xform
    sx = math.hypot(t.M00, t.M10)
    sy = math.hypot(t.M01, t.M11)
    if sx < 1e-12 or sy < 1e-12 or abs(t.M22) < 1e-12:
        raise ValueError('無效的區塊變換')
    rotation = math.degrees(math.atan2(t.M10, t.M00))
    sign = 1 if t.M00*t.M11-t.M01*t.M10 > 0 else -1
    expected_x = -sign*sy*math.sin(math.radians(rotation))
    expected_y = sign*sy*math.cos(math.radians(rotation))
    if (abs(t.M01-expected_x)>1e-7 or abs(t.M11-expected_y)>1e-7 or
        any(abs(getattr(t, key))>1e-8 for key in ('M02','M12','M20','M21')) or
        any(abs(getattr(t,key)-expected)>1e-8 for key,expected in [('M30',0),('M31',0),('M32',0),('M33',1)])):
        raise ValueError('尚未支援此區塊的傾斜或透視變換')
    return space.add_blockref(names[identifier], (t.M03,t.M13,t.M23),
                              dxfattribs={**attrs,'xscale':sx,'yscale':sy*sign,
                                          'zscale':t.M22,'rotation':rotation})


def add_linear_dimension(space, geometry, attrs):
    points=geometry.Points
    p1,p2=points['defpt1'],points['defpt2']
    a,b=points['arrowpt1'],points['arrowpt2']
    if abs(a.Y-b.Y)<1e-6:
        angle=0
    elif abs(a.X-b.X)<1e-6:
        angle=90
    else:
        raise ValueError('尚未支援傾斜的尺寸標註')
    base=((a.X+b.X)/2,(a.Y+b.Y)/2)
    dim=space.add_linear_dim(base,(p1.X,p1.Y),(p2.X,p2.Y),angle=angle,
                             text=geometry.PlainText,dxfattribs=attrs)
    dim.render()
    return dim.dimension
