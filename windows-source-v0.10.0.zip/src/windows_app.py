"""Windowless Windows entry point; accepts Explorer drag-and-drop arguments."""
import argparse
import json
import os
from pathlib import Path
import sys
from datetime import datetime, timezone

from converter import convert_one


def notify(title, message, failed=False, duration=8):
    """Show a Windows notification through a temporary tray icon, without a window."""
    if os.name != 'nt':
        return False
    import ctypes as c
    from ctypes import wintypes as w
    import time

    class NotifyIconData(c.Structure):
        _fields_ = [('cbSize', w.DWORD), ('hWnd', w.HWND), ('uID', w.UINT),
                    ('uFlags', w.UINT), ('uCallbackMessage', w.UINT), ('hIcon', w.HICON),
                    ('szTip', w.WCHAR * 128), ('dwState', w.DWORD), ('dwStateMask', w.DWORD),
                    ('szInfo', w.WCHAR * 256), ('uTimeout', w.UINT), ('szInfoTitle', w.WCHAR * 64),
                    ('dwInfoFlags', w.DWORD), ('guidItem', c.c_ubyte * 16), ('hBalloonIcon', w.HICON)]

    user = c.WinDLL('user32', use_last_error=True)
    shell = c.WinDLL('shell32', use_last_error=True)
    user.CreateWindowExW.argtypes = [w.DWORD,w.LPCWSTR,w.LPCWSTR,w.DWORD,c.c_int,c.c_int,
                                   c.c_int,c.c_int,w.HWND,w.HMENU,w.HINSTANCE,c.c_void_p]
    user.CreateWindowExW.restype = w.HWND
    user.LoadIconW.argtypes = [w.HINSTANCE, c.c_void_p]
    user.LoadIconW.restype = w.HICON
    user.DestroyWindow.argtypes = [w.HWND]
    user.PeekMessageW.argtypes = [c.POINTER(w.MSG),w.HWND,w.UINT,w.UINT,w.UINT]
    user.TranslateMessage.argtypes = [c.POINTER(w.MSG)]
    user.DispatchMessageW.argtypes = [c.POINTER(w.MSG)]
    user.DispatchMessageW.restype = c.c_ssize_t
    shell.Shell_NotifyIconW.argtypes = [w.DWORD,c.POINTER(NotifyIconData)]
    shell.Shell_NotifyIconW.restype = w.BOOL
    hwnd = user.CreateWindowExW(0x80, 'STATIC', '3DM to DXF notification', 0,
                               0,0,0,0,None,None,None,None)
    if not hwnd:
        return False
    data = NotifyIconData()
    data.cbSize = c.sizeof(data)
    data.hWnd = hwnd
    data.uID = 1
    data.uFlags = 2 | 4 | 16  # icon, tooltip, balloon
    data.hIcon = user.LoadIconW(None,c.c_void_p(32512))
    data.szTip = '3DM to DXF'
    data.szInfoTitle = title[:63]
    data.szInfo = message[:255]
    data.dwInfoFlags = 3 if failed else 1
    data.uTimeout = 10000
    accepted = False
    try:
        accepted = bool(shell.Shell_NotifyIconW(0,c.byref(data)))
        if accepted:
            end = time.monotonic() + duration
            msg = w.MSG()
            while time.monotonic() < end:
                while user.PeekMessageW(c.byref(msg),None,0,0,1):
                    user.TranslateMessage(c.byref(msg))
                    user.DispatchMessageW(c.byref(msg))
                time.sleep(0.05)
        return accepted
    finally:
        if accepted:
            shell.Shell_NotifyIconW(2,c.byref(data))
        user.DestroyWindow(hwnd)


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')


def main(argv=None):
    parser = argparse.ArgumentParser(description='Drag 3DM files onto this executable to export DXF.')
    parser.add_argument('files', nargs='*')
    parser.add_argument('--no-notify', action='store_true', help='For automated verification')
    parser.add_argument('--report', type=Path, help='Write a batch status JSON')
    parser.add_argument('--notification-check', action='store_true', help='Verify Windows notification API')
    args = parser.parse_args(argv)
    if args.notification_check:
        accepted = notify('3DM to DXF', 'Notification API test', duration=0.2)
        if args.report:
            write_json(args.report,{'notification_api_accepted':accepted})
        return 0 if accepted else 1
    if not args.files:
        if not args.no_notify:
            notify('3DM → DXF', '請將 .3dm 檔案拖到 EXE 圖示。\nDrag .3dm files onto the EXE icon.')
        return 0
    results = []
    for filename in args.files:
        source = Path(filename)
        try:
            source = source.resolve(strict=True)
            if source.suffix.lower() != '.3dm':
                raise ValueError('僅接受 .3dm 檔案 / Only .3dm files are supported')
            output, warnings = convert_one(source)
            if warnings:
                raise RuntimeError('轉檔未完整保留物件 / Incomplete conversion')
            results.append({'source':str(source),'output':output,'success':True})
        except Exception as error:
            results.append({'source':str(source),'success':False,'error':str(error)})
            try:
                source.with_name(source.name+'.conversion-error.txt').write_text(str(error)+'\n',encoding='utf-8')
            except OSError:
                pass
    failed = sum(not r['success'] for r in results)
    status = {'version':'0.10.0','timestamp':datetime.now(timezone.utc).isoformat(),
              'succeeded':len(results)-failed,'failed':failed,'results':results}
    log_root = Path(os.environ.get('LOCALAPPDATA',str(Path.home()))) / '3DM-to-DXF' / 'logs'
    try:
        write_json(log_root / ('batch-'+datetime.now().strftime('%Y%m%d-%H%M%S')+f'-{os.getpid()}.json'),status)
    except OSError:
        pass
    if args.report:
        write_json(args.report,status)
    if not args.no_notify:
        message = f"成功 {status['succeeded']} 個，失敗 {failed} 個 / {status['succeeded']} succeeded, {failed} failed."
        if failed:
            first = next(r for r in results if not r['success'])
            message += '\n'+Path(first['source']).name+': '+first['error'][:150]
        notify('3DM → DXF'+(' 部分失敗' if failed else ' 完成'),message,failed=bool(failed))
    return 1 if failed else 0


if __name__ == '__main__':
    raise SystemExit(main())
