"""No-Rhino 3DM to DXF worker. Converts a deliberately strict geometry subset."""
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import traceback
from collections import Counter

import ezdxf
from ezdxf.math import OCS
import rhino3dm as r3d


def xyz(point):
    return (float(point.X), float(point.Y), float(point.Z))


def layer_name(model, item):
    index = item.Attributes.LayerIndex
    try:
        name = model.Layers[index].FullPath or model.Layers[index].Name
    except (IndexError, TypeError):
        name = "0"
    # AutoCAD layer names do not support several Rhino name characters.
    return "".join("_" if char in '<>/\\":;?*|=' else char for char in name)[:200] or "0"


def add_round_curve(space, geometry, attributes):
    """Write exact planar circles/arcs, including planes tilted in 3D."""
    circle = geometry.TryGetCircle()
    if circle is not None:
        normal = xyz(circle.Plane.ZAxis)
        center = OCS(normal).from_wcs(xyz(circle.Center))
        space.add_circle(center, circle.Radius,
                         dxfattribs={**attributes, "extrusion": normal})
        return True
    arc = geometry.TryGetArc()
    if arc is None:
        return False
    if arc.IsCircle:
        normal = xyz(arc.Plane.ZAxis)
        center = OCS(normal).from_wcs(xyz(arc.Center))
        space.add_circle(center, arc.Radius,
                         dxfattribs={**attributes, "extrusion": normal})
        return True
    normal = xyz(arc.Plane.ZAxis)
    ocs = OCS(normal)
    center = ocs.from_wcs(xyz(arc.Center))
    start = ocs.from_wcs(xyz(arc.StartPoint)) - center
    end = ocs.from_wcs(xyz(arc.EndPoint)) - center
    start_angle = math.degrees(math.atan2(start.y, start.x)) % 360
    end_angle = math.degrees(math.atan2(end.y, end.x)) % 360
    space.add_arc(center, arc.Radius, start_angle, end_angle,
                  dxfattribs={**attributes, "extrusion": normal})
    return True


def add_object(space, geometry, layer, styles=None):
    attributes = {"layer": layer}
    if isinstance(geometry, r3d.Point):
        space.add_point(xyz(geometry.Location), dxfattribs=attributes)
    elif isinstance(geometry, r3d.Curve):
        if add_round_curve(space, geometry, attributes):
            return
        polyline = geometry.TryGetPolyline()
        if polyline is not None:
            points = [xyz(point) for point in polyline]
            if len(points) < 2:
                raise ValueError("曲線頂點不足")
            space.add_polyline3d(points, dxfattribs=attributes)
        elif isinstance(geometry, r3d.PolyCurve):
            for index in range(geometry.SegmentCount):
                add_object(space, geometry.SegmentCurve(index), layer, styles)
        elif isinstance(geometry, r3d.NurbsCurve):
            points = [geometry.Points[index] for index in range(len(geometry.Points))]
            if any(point.W == 0 for point in points):
                raise ValueError("NURBS 控制點權重為零")
            control_points = [(point.X / point.W, point.Y / point.W, point.Z / point.W) for point in points]
            weights = [point.W for point in points]
            knots = [geometry.Knots[0]] + [geometry.Knots[index] for index in range(len(geometry.Knots))] + [geometry.Knots[len(geometry.Knots) - 1]]
            spline = space.add_rational_spline(control_points, weights,
                                                degree=geometry.Degree, knots=knots,
                                                dxfattribs=attributes)
            if geometry.IsClosed:
                spline.dxf.flags |= 1
            if geometry.IsPeriodic:
                spline.dxf.flags |= 2
        else:
            raise ValueError("曲線類型尚未支援：" + type(geometry).__name__)
    elif isinstance(geometry, r3d.Mesh):
        for face_index in range(len(geometry.Faces)):
            valid, a, b, c, d = geometry.Faces.GetFaceVertices(face_index)
            if not valid:
                raise ValueError("無效的網格面")
            vertices = [xyz(a), xyz(b), xyz(c)]
            if xyz(c) != xyz(d):
                vertices.append(xyz(d))
            space.add_3dface(vertices, dxfattribs=attributes)
    elif isinstance(geometry, r3d.Text):
        style = (styles or {}).get(str(geometry.DimensionStyleId))
        height = geometry.GetTextHeight(style) if style is not None else 2.5
        plane = geometry.Plane
        normal = xyz(plane.ZAxis)
        ocs = OCS(normal)
        center = ocs.from_wcs(xyz(plane.Origin))
        axis = xyz(plane.XAxis)
        tip = ocs.from_wcs(tuple(x + y for x, y in zip(xyz(plane.Origin), axis))) - center
        angle = math.degrees(math.atan2(tip.y, tip.x))
        for line_number, line in enumerate(geometry.PlainText.splitlines() or [""]):
            if not line:
                continue
            insert = (center.x, center.y - line_number * height * 1.2, center.z)
            space.add_text(line, height=height, rotation=angle,
                           dxfattribs={**attributes, "insert": insert,
                                       "extrusion": normal})
    elif isinstance(geometry, r3d.Brep):
        for edge in geometry.Edges:
            add_object(space, edge, layer, styles)
    else:
        raise ValueError("物件類型尚未支援：" + type(geometry).__name__)


def convert_one(source):
    import fidelity as f
    from ezdxf.colors import rgb2int
    model = r3d.File3dm.Read(str(source))
    if model is None:
        raise ValueError("無法讀取 3DM")
    drawing = ezdxf.new("R2018")
    drawing.appids.new(f.SOURCE_APP)
    units = {"Millimeters":4,"Centimeters":5,"Meters":6,"Inches":1,"Feet":2,"None":0}
    unit = str(model.Settings.ModelUnitSystem).split('.')[-1]
    if unit not in units:
        raise ValueError("尚未支援此單位："+unit)
    drawing.units=units[unit]
    space=drawing.modelspace()
    styles={str(style.Id):style for style in model.DimStyles}
    warnings=Counter()
    with tempfile.TemporaryDirectory(prefix="3dm-dxf-") as temporary:
        temporary=Path(temporary)
        metadata,loops=f.extract(source,temporary)
        block_names={str(d.Id):d.Name for d in model.InstanceDefinitions}
        member_ids={str(uid) for d in model.InstanceDefinitions for uid in d.GetObjectIds()}
        objects_by_id={str(item.Attributes.Id):item for item in model.Objects}
        for definition in model.InstanceDefinitions:
            drawing.blocks.new(name=definition.Name)
        export_counts=Counter()
        def export_item(item,target):
            geometry=item.Geometry
            uid=str(item.Attributes.Id)
            layer=layer_name(model,item)
            original=model.Layers[item.Attributes.LayerIndex]
            if layer not in drawing.layers:
                new=drawing.layers.new(layer,dxfattribs={'true_color':rgb2int(original.Color[:3])})
                if not original.Visible:new.off()
                if original.Locked:new.lock()
                if original.PlotWeight>0:
                    weights=[0,5,9,13,15,18,20,25,30,35,40,50,53,60,70,80,90,100,106,120,140,158,200,211]
                    new.dxf.lineweight=min(weights,key=lambda w:abs(w-original.PlotWeight*100))
            attrs={'layer':layer}
            if str(item.Attributes.ColorSource).endswith('ColorFromObject'):
                attrs['true_color']=rgb2int(item.Attributes.ObjectColor[:3])
            if not item.Attributes.Visible:attrs['invisible']=1
            try:
                if geometry.ObjectType==r3d.ObjectType.Detail:
                    data=metadata['details'][uid]
                    if abs(data['direction'][2]-1)>1e-8:
                        raise ValueError('尚未支援非俯視版面視窗')
                    target=drawing.layouts.get('Layout1')
                    x0,y0,x1,y1=data['bounds']
                    target.page_setup(size=(max(x1+10,420),max(y1+10,297)),margins=(0,0,0,0))
                    entity=target.add_viewport(center=((x0+x1)/2,(y0+y1)/2),size=(x1-x0,y1-y0),
                       view_center_point=data['target'][:2],view_height=data['height'],status=2,dxfattribs=attrs)
                    entities=[entity]
                elif isinstance(geometry,r3d.InstanceReference):
                    entities=[f.add_instance(target,geometry,block_names,attrs)]
                elif isinstance(geometry,r3d.DimLinear):
                    entities=[f.add_linear_dimension(target,geometry,attrs)]
                elif isinstance(geometry,r3d.Hatch):
                    entities=[f.add_hatch(target,geometry,uid,metadata,loops,attrs)]
                elif isinstance(geometry,r3d.Text):
                    entities=[f.add_text(target,geometry,uid,metadata,attrs)]
                elif isinstance(geometry,r3d.Brep):
                    entities=[f.add_picture(drawing,target,model,item,source,attrs)]
                else:
                    before={e.dxf.handle for e in target}
                    add_object(target,geometry,layer,styles)
                    entities=[e for e in target if e.dxf.handle not in before]
                    for entity in entities:entity.update_dxf_attribs(attrs)
                if not entities:raise ValueError('物件沒有產生輸出')
                for entity in entities:entity.set_xdata(f.SOURCE_APP,[(1000,uid)])
                export_counts[uid]+=len(entities)
            except Exception as error:
                raise ValueError('物件 {}（{}）：{}'.format(uid,type(geometry).__name__,error)) from error
        for definition in model.InstanceDefinitions:
            block=drawing.blocks.get(definition.Name)
            for uid in definition.GetObjectIds():
                item=objects_by_id.get(str(uid))
                if item is None:raise ValueError('區塊定義缺少物件：'+str(uid))
                export_item(item,block)
        for index,item in enumerate(model.Objects):
            if str(item.Attributes.Id) in member_ids:continue
            if str(item.Attributes.ActiveSpace).endswith('PageSpace') and item.Geometry.ObjectType!=r3d.ObjectType.Detail:
                raise ValueError('尚未支援此版面物件')
            export_item(item,space)
        if len(export_counts)!=len(model.Objects):
            raise RuntimeError('原檔物件覆蓋核對失敗')
        dxf,restored=f.write_verified(drawing,temporary)
        for number in range(10000):
            destination=source.with_name(source.stem+('' if number==0 else '_'+str(number))+'.dxf')
            try:
                with open(dxf,'rb') as src,open(destination,'xb') as dst:
                    try:shutil.copyfileobj(src,dst)
                    except Exception:
                        destination.unlink(missing_ok=True)
                        raise
                report={'source_objects':len(model.Objects),'verified_source_objects':len(f.inventory(restored)),
                    'entities':dict(Counter(e.dxftype() for block in restored.blocks for e in block if e.has_xdata(f.SOURCE_APP))),
                    'units':unit,'hidden_layers':[l.dxf.name for l in drawing.layers if l.is_off()],
                    'validation':'DXF 直接寫入後回讀：來源物件 ID、類型、數量、填色邊界數量一致；DXF audit 無未修復錯誤',
                    'limitations':['字型顯示取決於接收端是否安裝原字型','圖片是外部參照，請連同 _embedded_files 資料夾一起移動','原檔隱藏的圖層仍保持隱藏']}
                destination.with_suffix('.dxf.verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
                return str(destination),warnings
            except FileExistsError:continue
        raise RuntimeError('同名 DXF 檔案過多')


def main(job_directory):
    folder = Path(job_directory)
    with (folder / "job.json").open(encoding="utf-8") as stream:
        job = json.load(stream)
    succeeded = failed = partial = 0
    first_error = ""
    for filename in job["files"]:
        error_report = Path(filename).with_name(Path(filename).name + ".conversion-error.txt")
        warning_report = Path(filename).with_name(Path(filename).name + ".conversion-warning.txt")
        try:
            output, warnings = convert_one(Path(filename))
            if warnings:
                lines = ["部分轉換：" + output, "以下物件未完整保留："]
                lines.extend("- {}：{} 個".format(name, count) for name, count in warnings.items())
                warning_report.write_text("\n".join(lines) + "\n", encoding="utf-8")
                partial += 1
            else:
                pass
            succeeded += 1
        except Exception as error:
            failed += 1
            if not first_error:
                first_error = "{}：{}".format(Path(filename).name, error)
            try:
                error_report.write_text(str(error) + "\n", encoding="utf-8")
            except OSError:
                pass
            traceback.print_exc()
    status = {"succeeded": succeeded, "failed": failed, "partial": partial,
              "first_error": first_error}
    temporary = folder / "status.tmp"
    temporary.write_text(json.dumps(status, ensure_ascii=False), encoding="utf-8")
    os.replace(temporary, folder / "status.json")


if __name__ == "__main__":
    try:
        main(sys.argv[1])
    except Exception as error:
        folder = Path(sys.argv[1])
        (folder / "status.json").write_text(json.dumps({"succeeded": 0, "failed": 1,
            "first_error": str(error)}, ensure_ascii=False), encoding="utf-8")
        raise

