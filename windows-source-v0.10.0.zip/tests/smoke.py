"""Test core geometry and the packaged EXE with entirely synthetic fixtures."""
import argparse
from collections import Counter
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import uuid

import ezdxf
import rhino3dm as r

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from converter import convert_one
from fidelity import inventory


def make_drawing(path, native_fixture):
    subprocess.run([str(native_fixture),str(path)],check=True)
    model=r.File3dm.Read(str(path))
    layer=r.Layer(); layer.Name='日本語 中文 測試'; layer.Color=(240,80,30,255)
    layer.Visible=False; layer.Locked=True
    index=model.Layers.Add(layer)
    attr=r.ObjectAttributes(); attr.LayerIndex=index
    model.Objects.AddPoint(r.Point3d(2,3,4),attr)
    model.Objects.AddLine(r.Point3d(0,0,0),r.Point3d(10,20,0))
    model.Objects.AddArc(r.Arc(r.Point3d(0,0,0),5.0,1.2))
    model.Objects.AddCircle(r.Circle(r.Point3d(20,20,0),2.0))
    points=[r.Point3d(0,0,0),r.Point3d(1,3,1),r.Point3d(3,2,2),r.Point3d(5,0,0)]
    model.Objects.AddCurve(r.NurbsCurve.Create(False,3,points))
    mesh=r.Mesh()
    for p in [(0,0,0),(1,0,0),(1,1,0),(0,1,0)]: mesh.Vertices.Add(*p)
    mesh.Faces.AddFace(0,1,2,3)
    model.Objects.AddMesh(mesh)
    member=r.LineCurve(r.Point3d(0,0,0),r.Point3d(4,0,0))
    idef_index=model.InstanceDefinitions.Add('SyntheticBlock','Test only','', '', r.Point3d(0,0,0),(member,),(r.ObjectAttributes(),))
    definition=model.InstanceDefinitions.FindIndex(idef_index)
    transform=r.Transform.Translation(50,60,0)
    model.Objects.AddInstanceObject(r.InstanceReference(definition.Id,transform))
    assert model.Write(str(path),8)
    return len(model.Objects)


def verify(path, count):
    drawing=ezdxf.readfile(path)
    assert len(inventory(drawing))==count
    audit=drawing.audit()
    assert not audit.has_errors and not audit.has_fixes
    kinds=Counter(e.dxftype() for b in drawing.blocks for e in b)
    for kind in ['HATCH','MTEXT','DIMENSION','INSERT','ARC','SPLINE','3DFACE','POINT']:
        assert kinds[kind]>0,(kind,kinds)
    hatch=drawing.modelspace().query('HATCH')[0]
    assert len(hatch.paths)==2
    assert drawing.units==4
    assert drawing.layers.get('日本語 中文 測試').is_off()
    assert drawing.layers.get('日本語 中文 測試').is_locked()
    blockref=drawing.modelspace().query('INSERT')[0]
    assert tuple(blockref.dxf.insert)==(50,60,0)
    return dict(kinds)


def run(exe=None, fixture=None, report=None):
    fixture=Path(fixture or ROOT/'build-native/Release/make_fixture.exe').resolve()
    with tempfile.TemporaryDirectory(prefix='3dm-dxf-test-') as temp:
        folder=Path(temp)/'中文 日本語 space'; folder.mkdir()
        source=folder/'測試 ねこ.3dm'
        count=make_drawing(source,fixture)
        existing=source.with_suffix('.dxf'); existing.write_bytes(b'KEEP EXISTING')
        if exe:
            status_path=folder/'batch.json'
            result=subprocess.run([str(Path(exe).resolve()),'--no-notify','--report',str(status_path),str(source)],timeout=180)
            assert result.returncode==0,result.returncode
            status=json.loads(status_path.read_text(encoding='utf-8'))
            assert status['succeeded']==1 and status['failed']==0,status
            output=Path(status['results'][0]['output'])
        else:
            output=Path(convert_one(source)[0])
        assert output.name==source.stem+'_1.dxf'
        assert existing.read_bytes()==b'KEEP EXISTING'
        entities=verify(output,count)
        # Mixed batches must finish the valid file and report the unsupported solid.
        bad=folder/'unsupported.3dm'
        model=r.File3dm();layer=r.Layer();layer.Name='Default';model.Layers.Add(layer)
        model.Objects.AddBrep(r.Sphere(r.Point3d(0,0,0),1).ToBrep());model.Write(str(bad),8)
        if exe:
            status_path=folder/'mixed.json'
            result=subprocess.run([str(Path(exe).resolve()),'--no-notify','--report',str(status_path),str(source),str(bad)],timeout=180)
            assert result.returncode==1
            status=json.loads(status_path.read_text(encoding='utf-8'))
            assert (status['succeeded'],status['failed'])==(1,1),status
            assert bad.with_name(bad.name+'.conversion-error.txt').is_file()
        else:
            try: convert_one(bad)
            except ValueError: pass
            else: raise AssertionError('Unsupported Brep did not fail')
        assert not bad.with_suffix('.dxf').exists()
        data={'passed':True,'source_objects':count,'entities':entities,
              'checks':['Unicode paths','hatch inner boundary','block placement','dimension','NURBS','mesh',
                        'layer visibility and locking','DXF audit','no overwrite','unsupported solid rejection',
                        'mixed batch' if exe else 'core API']}
        if report:
            Path(report).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps(data,ensure_ascii=False))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--exe');p.add_argument('--fixture');p.add_argument('--report')
    args=p.parse_args();run(args.exe,args.fixture,args.report)
